#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <tf2_ros/transform_broadcaster.h>

class FakeOdomNode : public rclcpp::Node {
public:
    FakeOdomNode() : Node("fake_odom_node") {
        publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", 10);
        tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(100),
            std::bind(&FakeOdomNode::publishOdom, this));
    }

private:
    void publishOdom() {
        auto now = this->get_clock()->now();

        // 0.3 m/s sabit hızla x yönünde gidiyor
        static double x = 0.0;
        x += 0.3 * 0.1;  // 0.3 m/s * 0.1s

        nav_msgs::msg::Odometry odom;
        odom.header.stamp = now;
        odom.header.frame_id = "odom";
        odom.child_frame_id = "base_link";
        odom.pose.pose.position.x = x;
        odom.pose.pose.position.y = 0.0;
        odom.pose.pose.orientation.w = 1.0;

        odom.twist.twist.linear.x = 0.3;

        publisher_->publish(odom);

        geometry_msgs::msg::TransformStamped transform;
        transform.header.stamp = now;
        transform.header.frame_id = "odom";
        transform.child_frame_id = "base_link";
        transform.transform.translation.x = x;
        transform.transform.translation.y = 0.0;
        transform.transform.rotation.w = 1.0;

        tf_broadcaster_->sendTransform(transform);
    }

    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr publisher_;
    std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<FakeOdomNode>());
    rclcpp::shutdown();
    return 0;
}

