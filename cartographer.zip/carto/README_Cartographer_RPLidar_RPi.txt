Cartographer + RPLidar A1M8 (ROS 2 Jazzy) — Raspberry Pi Kurulum & Çalıştırma
================================================================================

Kapsam
------
Bu belge, RPLidar A1M8’i sllidar_ros2 sürücüsüyle çalıştırıp Cartographer 2D SLAM ile harita üretmeyi ve iki tipik sorunu gidermeyi amaçlar:
1) Harita üst üste binme / döner gibi görünme
2) RViz2 GLSL shader hatası / donma

Not: Lidar’ı elde çevirerek harita çıkarılmaz; lidar robot gövdesine rijit bağlı olmalıdır. Haritayı değil robotu döndürün.

--------------------------------------------------------------------------------

0) Raspberry Pi üzerinde ön koşullar
------------------------------------
sudo usermod -a -G dialout $USER
# Sonra oturumu kapatıp açın veya:
reboot

Gerekli paketler:
sudo apt update
sudo apt install -y ros-jazzy-cartographer-ros ros-jazzy-rviz2 ros-jazzy-nav2-map-server \
                    ros-jazzy-tf2-tools graphviz

--------------------------------------------------------------------------------

1) Dosyaları Raspberry Pi’ye aktarma
------------------------------------
PC’nizde hazırladığınız workspace’i Pi’ye kopyalamak için örnek:
rsync -avh ~/Masaüstü/cartographer_ws/  pi@raspberrypi.local:~/Masaüstü/cartographer_ws/
# veya scp:
# scp -r ~/Masaüstü/cartographer_ws pi@raspberrypi.local:~/Masaüstü/

Beklenen yapı:
~/Masaüstü/cartographer_ws/
  ├── src/
  │   ├── sllidar_ros2/            # DOĞRU: ROS 2 lidar sürücüsü
  │   └── rplidar_cartographer/    # launch + config (lua)

Eğer src/ altında rplidar_ros/ (ROS 1 sürücüsü) varsa silin ve sllidar_ros2 kullanın.

--------------------------------------------------------------------------------

2) Gerekli klasör ve install kuralı (bir kez)
---------------------------------------------
cd ~/Masaüstü/cartographer_ws/src/rplidar_cartographer
mkdir -p config launch

CMake install kuralı:
cd ~/Masaüstü/cartographer_ws/src/rplidar_cartographer
grep -q "install(.*config launch" CMakeLists.txt || \
printf '\\ninstall(DIRECTORY config launch DESTINATION share/${PROJECT_NAME})\\n' >> CMakeLists.txt

--------------------------------------------------------------------------------

3) Cartographer yapılandırması (config/cartographer.lua)
--------------------------------------------------------
A1M8 için örnek (12 m menzil). Motion filter satırına dikkat:

include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder = MAP_BUILDER,
  trajectory_builder = TRAJECTORY_BUILDER,

  map_frame = "map",
  tracking_frame = "base_link",
  published_frame = "base_link",
  odom_frame = "odom",

  provide_odom_frame = true,
  publish_frame_projected_to_2d = false,

  use_odometry = false,      -- /odom yayınlıyorsanız true yapın
  use_nav_sat = false,
  use_landmarks = false,

  num_laser_scans = 1,
  num_multi_echo_laser_scans = 0,
  num_subdivisions_per_laser_scan = 1,
  num_point_clouds = 0,

  lookup_transform_timeout_sec = 0.2,
  submap_publish_period_sec = 0.3,
  pose_publish_period_sec = 0.02,
  trajectory_publish_period_sec = 0.03,

  rangefinder_sampling_ratio = 1.0,
  odometry_sampling_ratio = 1.0,
  fixed_frame_pose_sampling_ratio = 1.0,
  imu_sampling_ratio = 1.0,
  landmarks_sampling_ratio = 1.0,
}

MAP_BUILDER.use_trajectory_builder_2d = true

-- Lidar menzili (A1M8 ≈ 12 m)
TRAJECTORY_BUILDER_2D.min_range = 0.10
TRAJECTORY_BUILDER_2D.max_range = 12.0
TRAJECTORY_BUILDER_2D.missing_data_ray_length = 12.0

-- IMU kullanımı (varsa açın)
TRAJECTORY_BUILDER_2D.use_imu_data = false

-- Tarama eşleyici & hareket filtresi
TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = true
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.linear_search_window = 0.08
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.translation_delta_cost_weight = 10.0
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.rotation_delta_cost_weight = 0.1
TRAJECTORY_BUILDER_2D.motion_filter.max_angle_radians = math.rad(10.0) -- 10°

-- Submap & optimizasyon
TRAJECTORY_BUILDER_2D.submaps.num_range_data = 35
TRAJECTORY_BUILDER_2D.submaps.grid_options_2d.resolution = 0.05
POSE_GRAPH.constraint_builder.min_score = 0.65
POSE_GRAPH.constraint_builder.global_localization_min_score = 0.7
POSE_GRAPH.optimization_problem.huber_scale = 1e2
POSE_GRAPH.optimize_every_n_nodes = 35

return options

Performans düşükse: use_online_correlative_scan_matching = false, submaps.num_range_data = 30 deneyin.

--------------------------------------------------------------------------------

4) Launch dosyası (launch/cartographer.launch.py)
-------------------------------------------------
Tam ve doğru sürüm:

import os
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    pkg_share = FindPackageShare(package='rplidar_cartographer').find('rplidar_cartographer')

    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    configuration_directory = LaunchConfiguration(
        'configuration_directory',
        default=os.path.join(pkg_share, 'config')
    )
    configuration_basename = LaunchConfiguration(
        'configuration_basename',
        default='cartographer.lua'
    )

    resolution = LaunchConfiguration('resolution', default='0.05')
    publish_period_sec = LaunchConfiguration('publish_period_sec', default='1.0')

    cartographer_node = Node(
        package='cartographer_ros',
        executable='cartographer_node',
        name='cartographer_node',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=[
            '-configuration_directory', configuration_directory,
            '-configuration_basename', configuration_basename
        ],
        remappings=[('scan', 'scan')]
    )

    occupancy_grid_node = Node(
        package='cartographer_ros',
        executable='cartographer_occupancy_grid_node',
        name='cartographer_occupancy_grid_node',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=[
            '-resolution', resolution,
            '-publish_period_sec', publish_period_sec
        ]
    )

    static_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'laser']
    )

    return LaunchDescription([
        static_tf,
        cartographer_node,
        occupancy_grid_node
    ])

--------------------------------------------------------------------------------

5) Build
--------
cd ~/Masaüstü/cartographer_ws
source /opt/ros/jazzy/setup.bash
rosdep update
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash

--------------------------------------------------------------------------------

6) Çalıştırma (4 Terminal)
--------------------------
T1 — Lidar sürücüsü (sllidar_ros2)
source ~/Masaüstü/cartographer_ws/install/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py \
  serial_port:=/dev/ttyUSB0 serial_baudrate:=115200 frame_id:=laser

T2 — Cartographer
source ~/Masaüstü/cartographer_ws/install/setup.bash
ros2 launch rplidar_cartographer cartographer.launch.py

T3 — RViz2 (Wayland’de X11 modunda açın)
QT_QPA_PLATFORM=xcb rviz2
# Fixed Frame: map
# Displays -> Add: Map(/map), LaserScan(/scan)

T4 — Harita kaydetme
ros2 run nav2_map_server map_saver_cli -f ~/Masaüstü/cartographer_ws/maps/my_map

--------------------------------------------------------------------------------

7) Hızlı testler / Sağlamlık kontrolleri
----------------------------------------
# Lidar veri geliyor mu?
ros2 topic list | grep scan
ros2 topic echo /scan --once
ros2 topic hz /scan

# TF’ler makul mü?
ros2 run tf2_ros tf2_echo map base_link
ros2 run tf2_tools view_frames   # frames.pdf üretir (graphviz gerekir)

# Cartographer node & topic’ler
ros2 node list
ros2 topic list | grep -E '/map|/submap'

--------------------------------------------------------------------------------

8) Sık görülen sorunlar ve çözümler
-----------------------------------
A) Harita üst üste biniyor / dönüyor
- Donanım & TF: Lidar robotla birlikte hareket etmeli. static_transform_publisher içindeki xyz/rpy doğru olmalı.
  ros2 run tf2_ros tf2_echo base_link laser
- Odometri/IMU: Varsa açın:
  use_odometry = true  (ve /odom yayın)
  TRAJECTORY_BUILDER_2D.use_imu_data = true  (ve /imu yayın)
- Sürüş paterni: Aynı anda hem keskin dönüp hem hızlı ilerlemeyin; kapalı çevrim (loop) izleyin.
- Parametreler: CPU düşükse use_online_correlative_scan_matching = false.

B) RViz2 GLSL shader hatası / donma
QT_QPA_PLATFORM=xcb rviz2
# İlk harita oluşana kadar LaserScan görüntüsünü kapalı tutup sonra açmak işe yarayabilir.
# En son çare (yavaş ama stabil):
LIBGL_ALWAYS_SOFTWARE=1 rviz2

C) Yanlış komut kullanımı
- ros2 topic echo -n 1 /scan  YANLIŞ
  Doğru: ros2 topic echo /scan --once

- rplidar.launch.py bulunamadı: ROS 1 sürücüsü kullanılıyor. sllidar_ros2’ye geçin.

--------------------------------------------------------------------------------

9) Temiz build (quick reset)
----------------------------
cd ~/Masaüstü/cartographer_ws
rm -rf build/ install/ log/
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash

--------------------------------------------------------------------------------

10) Raspberry Pi notları
------------------------
- Ubuntu 24.04 aarch64 + ROS 2 Jazzy önerilir.
- Headless kullanımda Pi’de yalnızca T1+T2’yi çalıştırıp RViz2’yi dizüstünde çalıştırın.
- Güç ve soğutma kritik; CPU throttling harita kalitesini bozar.

--------------------------------------------------------------------------------

Değişiklikler / Neler Güncellendi
---------------------------------
1) Sürücü paketi değişti: rplidar_ros (ROS 1) kaldırıldı, yerine sllidar_ros2 eklendi.
   Çalıştırma:
   ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/ttyUSB0 serial_baudrate:=115200 frame_id:=laser

2) Launch dosyası düzeltildi: cartographer.launch.py tamamlandı; static_transform_publisher ve return hataları giderildi.

3) Cartographer konfig güncellendi:
   TRAJECTORY_BUILDER_2D.motion_filter.max_angle_radians = math.rad(10.0)

4) Komut düzeltmeleri:
   ros2 topic echo -n 1 /scan  →  ros2 topic echo /scan --once

5) Install kuralı eklendi:
   config/ ve launch/ klasörleri CMake install ile share/ altına kopyalanıyor.

6) RViz2 notu:
   Wayland’da GLSL hatasına karşı QT_QPA_PLATFORM=xcb önerildi.

7) Hata giderme bölümleri genişletildi:
   TF, odometri/IMU ve sürüş paterni hakkında ek yönlendirmeler eklendi.
