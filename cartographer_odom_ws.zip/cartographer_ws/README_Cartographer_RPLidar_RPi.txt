Cartographer + RPLidar A1M8 (ROS 2 Jazzy) — Raspberry Pi Workspace Setup & Troubleshooting
===========================================================================================

Scope
-----
This README explains how to run Cartographer SLAM with an RPLidar A1M8 on ROS 2 **Jazzy**,
and how to fix the two issues you saw:
1) Map layers overlapping / rotating while mapping
2) RViz2 GLSL shader error

The commands assume a Debian/Ubuntu system (e.g., **Ubuntu 24.04 aarch64** on Raspberry Pi 5)
and a workspace at: `~/Masaüstü/cartographer_ws`


0) Prerequisites (once)
-----------------------
- Install ROS 2 Jazzy (binary/deb) and essential tools.
- Make sure your user can access serial ports (log out/in after this):
```
sudo usermod -a -G dialout $USER
```
- Optional QA tools:
```
sudo apt update
sudo apt install -y ros-jazzy-cartographer-ros ros-jazzy-rviz2 ros-jazzy-nav2-map-server \
                    ros-jazzy-tf2-tools graphviz
```


1) Workspace layout
-------------------
We expect this structure (you already have it):
```
~/Masaüstü/cartographer_ws/
├── src/
│   ├── rplidar_ros/           # lidar driver (from source, or use packaged driver)
│   └── rplidar_cartographer/  # our bringup package (launch + config)
```


2) Create required folders/files (if missing)
---------------------------------------------
```
cd ~/Masaüstü/cartographer_ws/src/rplidar_cartographer
mkdir -p config launch
```

2a) Create the Cartographer config (A1M8 ≈ 12 m range)
------------------------------------------------------
```
tee config/cartographer.lua > /dev/null <<'EOF'
include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder = MAP_BUILDER,
  trajectory_builder = TRAJECTORY_BUILDER,

  map_frame = "map",
  tracking_frame = "base_link",
  published_frame = "base_link",
  odom_frame = "odom",

  provide_odom_frame = true,
  publish_frame_projected_to_2d = false,

  use_odometry = false,   -- set true if you publish /odom
  use_nav_sat = false,
  use_landmarks = false,

  num_laser_scans = 1,
  num_multi_echo_laser_scans = 0,
  num_subdivisions_per_laser_scan = 1,
  num_point_clouds = 0,

  lookup_transform_timeout_sec = 0.2,
  submap_publish_period_sec = 0.3,
  pose_publish_period_sec = 0.02,
  trajectory_publish_period_sec = 0.03,

  rangefinder_sampling_ratio = 1.0,
  odometry_sampling_ratio = 1.0,
  fixed_frame_pose_sampling_ratio = 1.0,
  imu_sampling_ratio = 1.0,
  landmarks_sampling_ratio = 1.0,
}

MAP_BUILDER.use_trajectory_builder_2d = true

-- Lidar range (A1M8 ≈ 12 m)
TRAJECTORY_BUILDER_2D.min_range = 0.10
TRAJECTORY_BUILDER_2D.max_range = 12.0
TRAJECTORY_BUILDER_2D.missing_data_ray_length = 12.0

-- IMU setting (enable if you have /imu)
TRAJECTORY_BUILDER_2D.use_imu_data = false

-- Scan matcher & motion filter (tune to reduce rotation drift)
TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = true
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.linear_search_window = 0.08
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.translation_delta_cost_weight = 10.0
TRAJECTORY_BUILDER_2D.real_time_correlative_scan_matcher.rotation_delta_cost_weight = 0.1
TRAJECTORY_BUILDER_2D.motion_filter.max_angle_radians = math.rad(0.17) -- ~10 deg

-- Submaps & optimization
TRAJECTORY_BUILDER_2D.submaps.num_range_data = 35
TRAJECTORY_BUILDER_2D.submaps.grid_options_2d.resolution = 0.05
POSE_GRAPH.constraint_builder.min_score = 0.65
POSE_GRAPH.constraint_builder.global_localization_min_score = 0.7
POSE_GRAPH.optimization_problem.huber_scale = 1e2
POSE_GRAPH.optimize_every_n_nodes = 35

return options
EOF
```

2b) Create the launch file
--------------------------
```
tee launch/cartographer.launch.py > /dev/null <<'EOF'
import os
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    pkg_share = FindPackageShare(package='rplidar_cartographer').find('rplidar_cartographer')

    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    configuration_directory = LaunchConfiguration('configuration_directory', default=os.path.join(pkg_share, 'config'))
    configuration_basename = LaunchConfiguration('configuration_basename', default='cartographer.lua')

    resolution = LaunchConfiguration('resolution', default='0.05')
    publish_period_sec = LaunchConfiguration('publish_period_sec', default='1.0')

    cartographer_node = Node(
        package='cartographer_ros',
        executable='cartographer_node',
        name='cartographer_node',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=[
            '-configuration_directory', configuration_directory,
            '-configuration_basename', configuration_basename
        ],
        remappings=[('scan', 'scan')]
    )

    occupancy_grid_node = Node(
        package='cartographer_ros',
        executable='cartographer_occupancy_grid_node',
        name='cartographer_occupancy_grid_node',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=['-resolution', resolution, '-publish_period_sec', publish_period_sec]
    )

    # Adjust xyz/rpy if lidar is not exactly on base_link
    static_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0','0','0','0','0','0','base_link','laser']
    )

    return LaunchDescription([static_tf, cartographer_node, occupancy_grid_node])
EOF
```

2c) Ensure install rules (only once)
------------------------------------
If your bringup package is a simple “config + launch” package, append this line to `CMakeLists.txt`:
```
cd ~/Masaüstü/cartographer_ws/src/rplidar_cartographer
grep -q "install(.*config launch" CMakeLists.txt || \
printf '\ninstall(DIRECTORY config launch DESTINATION share/${PROJECT_NAME})\n' >> CMakeLists.txt
```


3) Build
--------
```
cd ~/Masaüstü/cartographer_ws
source /opt/ros/jazzy/setup.bash
rosdep update
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```


4) Run — 4 terminals
--------------------

T1 — Lidar driver (adjust serial port if needed)
```
source ~/Masaüstü/cartographer_ws/install/setup.bash
ros2 launch rplidar_ros rplidar.launch.py serial_port:=/dev/ttyUSB0 frame_id:=laser
# Hız kontrol: ros2 topic echo -n 1 /scan
```

T2 — Cartographer
```
source ~/Masaüstü/cartographer_ws/install/setup.bash
ros2 launch rplidar_cartographer cartographer.launch.py
```

T3 — RViz2 (Wayland notu aşağıda)
```
rviz2
# Global Options -> Fixed Frame: map
# Displays -> Add: Map(/map), LaserScan(/scan)
```

T4 — Save map
```
ros2 run nav2_map_server map_saver_cli -f ~/Masaüstü/cartographer_ws/maps/my_map
```


5) Fix: Map overlaps / rotates while mapping
--------------------------------------------
A) Hardware & TF
- Lidar **robotla birlikte** hareket etmeli. Lidar’ı elde çevirerek map yapılmaz.
- `static_transform_publisher` içindeki xyz/rpy lidarın gerçek konumuna göre olmalı.
  Hızlı test:
  ```
  ros2 run tf2_ros tf2_echo base_link laser
  ```

B) Use odometry and/or IMU if available
- Edit `config/cartographer.lua`:
  - `use_odometry = true`  (and ensure `/odom` is being published)
  - `TRAJECTORY_BUILDER_2D.use_imu_data = true`  (and publish `/imu`)
- Rebuild + relaunch.

C) Tuning (lighter CPU, less drift)
- If CPU is weak, try:
  - `TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = false`
  - `TRAJECTORY_BUILDER_2D.submaps.num_range_data = 30`
- Slightly reduce:
  - `real_time_correlative_scan_matcher.linear_search_window = 0.05`
  - `motion_filter.max_angle_radians = math.rad(0.12)`
- Drive pattern:
  - Slow, avoid rotating and translating **at the same time**, do closed loops.


6) Fix: RViz2 GLSL shader error / freeze
----------------------------------------
Symptoms like:
```
[ERROR] [rviz2]: rviz/glsl120/indexed_8bit_image.vert
... GLSL link result : active samplers with a different type refer to the same texture image unit
```
Workarounds:
- If your desktop session uses **Wayland**, run RViz in X11 mode:
  ```
  QT_QPA_PLATFORM=xcb rviz2
  ```
  (Optional, to make it persistent for your user: `echo 'export QT_QPA_PLATFORM=xcb' >> ~/.bashrc`)
- If viewport freezes when Map & LaserScan are both visible, disable **LaserScan** display until the map first appears, then re-enable.
- As a last resort (slower): `LIBGL_ALWAYS_SOFTWARE=1 rviz2`


7) Sanity checks
----------------
```
# Lidar delivering data?
ros2 topic hz /scan
ros2 topic echo -n 1 /scan

# Frames OK?
ros2 run tf2_ros tf2_echo map base_link
ros2 run tf2_tools view_frames   # creates frames.pdf (requires graphviz)

# Cartographer nodes up?
ros2 node list
ros2 topic list | grep -E '/map|/scan|/submap'
```


8) Quick reset (clean build)
----------------------------
```
cd ~/Masaüstü/cartographer_ws
rm -rf build/ install/ log/
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash
```


9) Notes for Raspberry Pi
-------------------------
- Prefer Ubuntu **24.04 aarch64** for ROS 2 Jazzy on Pi 5.
- If headless, run RViz on a laptop and connect over the network; on the Pi only run T1+T2.
- Ensure adequate power and cooling; CPU throttling degrades mapping quality.


Good luck. If mapping still “ghosts/rotates”, share:
- A short rosbag with `/scan`, `/tf`, `/tf_static`, and (if available) `/odom`, `/imu`.
- A screenshot of RViz (Fixed Frame=map) and your `cartographer.lua`.
