#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "tf2_ros/transform_broadcaster.h"

class FakeOdomNode : public rclcpp::Node {
public:
    FakeOdomNode() : Node("fake_odom_node"), x_(0.0), y_(0.0), th_(0.0) {
        odom_pub_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", 10);
        tf_broadcaster_ = std::make_shared<tf2_ros::TransformBroadcaster>(this);

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(100),   // 10 Hz
            std::bind(&FakeOdomNode::publishOdom, this));
    }

private:
    void publishOdom() {
        rclcpp::Time now = this->now();

        double vx = 0.3;  // sabit hız (m/s)
        double dt = 0.1;  // 10 Hz olduğu için

        x_ += vx * dt;

        // Odometry mesajı
        auto odom = nav_msgs::msg::Odometry();
        odom.header.stamp = now;
        odom.header.frame_id = "odom";
        odom.child_frame_id = "base_link";

        odom.pose.pose.position.x = x_;
        odom.pose.pose.position.y = y_;
        odom.pose.pose.orientation.w = 1.0;

        odom.twist.twist.linear.x = vx;
        odom_pub_->publish(odom);

        // TF yayını
        geometry_msgs::msg::TransformStamped tf;
        tf.header.stamp = now;
        tf.header.frame_id = "odom";
        tf.child_frame_id = "base_link";
        tf.transform.translation.x = x_;
        tf.transform.translation.y = y_;
        tf.transform.rotation.w = 1.0;

        tf_broadcaster_->sendTransform(tf);
    }

    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub_;
    std::shared_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
    rclcpp::TimerBase::SharedPtr timer_;

    double x_, y_, th_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<FakeOdomNode>());
    rclcpp::shutdown();
    return 0;
}
