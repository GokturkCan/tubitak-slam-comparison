from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    base_frame = LaunchConfiguration('base_frame')
    odom_frame = LaunchConfiguration('odom_frame')
    map_frame  = LaunchConfiguration('map_frame')
    throttle_scans = LaunchConfiguration('throttle_scans')
    linearUpdate   = LaunchConfiguration('linearUpdate')
    angularUpdate  = LaunchConfiguration('angularUpdate')
    particles      = LaunchConfiguration('particles')

    return LaunchDescription([
        DeclareLaunchArgument('base_frame', default_value='base_link'),
        DeclareLaunchArgument('odom_frame', default_value='odom'),
        DeclareLaunchArgument('map_frame',  default_value='map'),
        DeclareLaunchArgument('throttle_scans', default_value='1'),
        DeclareLaunchArgument('linearUpdate',  default_value='0.2'),
        DeclareLaunchArgument('angularUpdate', default_value='0.2'),
        DeclareLaunchArgument('particles',     default_value='30'),

        Node(
            package='slam_gmapping',
            executable='slam_gmapping',   # <— derlenen ikili adı
            name='slam_gmapping',
            output='screen',
            parameters=[{
                'base_frame': base_frame,
                'odom_frame': odom_frame,
                'map_frame':  map_frame,
                'throttle_scans': throttle_scans,
                'linearUpdate':  linearUpdate,
                'angularUpdate': angularUpdate,
                'particles':     particles,
            }],
            remappings=[('scan', '/scan')],
        )
    ])

