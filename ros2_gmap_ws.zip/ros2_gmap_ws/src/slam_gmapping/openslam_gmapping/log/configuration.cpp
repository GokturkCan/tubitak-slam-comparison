#include "configuration.h"

namespace GMapping {

Configuration::~Configuration(){
}

};
